# TimeLock Blocker (টাইমলক ব্লকার)
### Redmi/POCO HyperOS ও আধুনিক অ্যান্ড্রয়েডের জন্য VpnService ভিত্তিক DNS ওয়েবসাইট ব্লকার

TimeLock Blocker একটি স্ট্রিক্ট (Strict Mode) ওয়েবসাইট ব্লকিং অ্যাপ্লিকেশন যা অ্যান্ড্রয়েডের অনুমোদিত `VpnService` ফ্রেমওয়ার্ক ব্যবহার করে লোকাল DNS সিঙ্কহোল (DNS Sinkhole) প্রযুক্তিতে তৈরি।